// Generated from c:\Users\frang\OneDrive\Escritorio\Facu\5to\TC\Repos\TC\primerproyecto\src\main\java\primerproyecto\primerproyecto.g4 by ANTLR 4.9.2

package primerproyecto;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link primerproyectoParser}.
 */
public interface primerproyectoListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link primerproyectoParser#s}.
	 * @param ctx the parse tree
	 */
	void enterS(primerproyectoParser.SContext ctx);
	/**
	 * Exit a parse tree produced by {@link primerproyectoParser#s}.
	 * @param ctx the parse tree
	 */
	void exitS(primerproyectoParser.SContext ctx);
}